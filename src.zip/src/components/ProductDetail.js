import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
// import "react-carousel/lib/carousel.css";
import { IconButton } from "@mui/material";
import { Add, Remove, Favorite, FavoriteBorder } from "@mui/icons-material";
import Button from '@mui/material/Button';
import Rating from '@mui/material/Rating';


function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState({});
  const [activeStep, setActiveStep] = useState(0);
  const [rating, setRating] = useState(0);
  const [quantity, setQuantity] = useState(1);

  const removeQuantity = () => {
    setQuantity((prevQuantity) => (prevQuantity > 1 ? --prevQuantity : prevQuantity));
  }

  const addQuantity = () => {
    setQuantity((prevQuantity) =>  ++prevQuantity)
  }
  const toggleFavorite = () => {
    setProduct((prevProduct) => ({ ...prevProduct, isLiked: !prevProduct.isLiked }));
  };
  useEffect(() => {
    // Check if there's a stored quantity in local storage
    const storedQuantity = JSON.parse(localStorage.getItem('selectedQuantity'));
    if (storedQuantity) {
      setQuantity(storedQuantity);
    } else {
      // If no stored quantity, fetch the product details
      axios
        .get(`https://dummyjson.com/products/${id}`)
        .then((res) => {
          setProduct(res.data);
          setRating(res.data.rating);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [id]);
  

  const handleThumbnailClick = (index) => {
    setActiveStep(index);
  };
  const addToCart = () => {
    // Retrieve existing cart items from local storage
    const existingCartItems = JSON.parse(localStorage.getItem('cart')) || [];
  
    // Check if the product with the same id already exists in the cart
    const existingCartItem = existingCartItems.find(item => item.id === product.id);
  
    if (existingCartItem) {
      // If the product is already in the cart, update its quantity
      existingCartItem.quantity += quantity;
    } else {
      // If the product is not in the cart, add it with the selected quantity
      existingCartItems.push({ ...product, quantity });
    }
  
    // Save the updated cart items back to local storage
    localStorage.setItem('cart', JSON.stringify(existingCartItems));
  };
  
  
  return (
    <div className="product-details-container">
      <div className="flex">
        <div className="thumbnails-container flex-col">
          {product.images &&
            product.images.map((image, index) => (
              <div
                key={index}
                className={`thumbnail ${activeStep === index ? "active-thumbnail" : ""
                  }`}
                onClick={() => handleThumbnailClick(index)}
              >
                <img
                  src={image}
                  alt={`Thumbnail ${index + 1}`}
                  style={{
                    width: "100%",
                    borderRadius: "8px",
                    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
                  }}
                />
              </div>
            ))}
        </div>
        <div className="main-image-container flex w-full h-96">
          <img
            src={product.images && product.images[activeStep]}
            alt={`Product ${activeStep + 1}`}
          />
        </div>
        <div className="product-info">
          <h2 className="product-title">{product.title}</h2>
          <p className="product-description">{product.description}</p>
          <p className="brand">Brand: {product.brand}</p>
          <p className="rating flex items-center">
            <span className="text-base">{rating}</span>
            <Rating name="half-rating-read" value={rating} precision={0.5} readOnly />
          </p>
          <p className="deal-of-the-day">Deal of the Day</p>
          <p className="discount">-{product.discountPercentage}% <span><span className="money-symbol">₹</span><span>{product.price}</span></span></p>
          <div className="buttons-container">
            <div className="flex justify-between align-center">
              <p>quantity</p>
              <div className="border-2">
                <IconButton onClick={removeQuantity}>
                  <Remove />
                </IconButton>
                <span>{quantity}</span>
                <IconButton onClick={addQuantity}>
                  <Add />
                </IconButton>
              </div>
            </div>
            <div className="flex justify-center items-center border-2 mt-2">
              <Button variant="text"><Link to={`/cart?quantity=${quantity}`} onClick={addToCart}>Add To Cart</Link> </Button>
            </div>
            <div className="flex justify-center items-center border-2 mt-2" onClick={toggleFavorite}>
              <IconButton>
                {product.isLiked ? (
                  <Favorite color="error" />
                ) : (
                  <FavoriteBorder />
                )}
              </IconButton>
              <span>Faviourite</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
