import React from 'react';
import { useLocation } from 'react-router-dom';

function AddToCart() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const quantity = searchParams.get('quantity') || 1; // Default to 1 if quantity is not provided

  return (
    <>
      <p>Selected Quantity: {quantity}</p>
      {/* Other AddToCart component content */}
    </>
  );
}

export default AddToCart;
