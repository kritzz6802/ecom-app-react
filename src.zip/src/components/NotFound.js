import React from "react";

export default function NotFound() {
  return (
    <div className="center">
      <h2>Not Found</h2>
      <iframe
        src="https://gifer.com/embed/AfSD"
        title="notfound"
        width="480"
        height="384.000"
        frameBorder="0"
        allowFullScreen
      ></iframe>
    </div>
  );
}
