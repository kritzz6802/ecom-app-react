import React from "react";

function HeadComponent() {
  return (
    <>
      <img
        className="imageStyle"
        src="https://static.wixstatic.com/media/84770f_b280c3fc0a5f405d9aa1f2c4e1bbeefc~mv2.jpg/v1/fill/w_1958,h_760,fp_0.71_0.32,q_90/84770f_b280c3fc0a5f405d9aa1f2c4e1bbeefc~mv2.webp"
        alt=""
      />
    </>
  );
}

export default HeadComponent;
